package com.example.orderservice.controller;

//import com.example.orderservice.dto.ProducDto;
import com.example.orderservice.dto.ProductDto;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "product-service")
public interface ProductClient {

    @GetMapping("/products/{id}")
    ProductDto getProduct(@PathVariable("id") String id);

    @PutMapping("/products/{id}/reduceStock")
    ProductDto reduceStock(@PathVariable("id") String id, @RequestParam("qty") int qty);
}