package com.example.orderservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.orderservice.dto.PaymentRequest;
import com.example.orderservice.dto.PaymentResponse;
import com.example.orderservice.dto.ProductDto;
import com.example.orderservice.entity.Order;
import com.example.orderservice.repository.OrderRepository;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private ProductClient productClient;

    @Autowired
    private PaymentClient paymentClient;

    @PostMapping
    public Order placeOrder(@RequestBody Order order) {
        ProductDto product = productClient.getProduct(order.getProductId());
        if (product == null || product.getStock() < order.getQuantity()) {
            order.setStatus("FAILED");
            return order;
        }

        double totalPrice = product.getPrice() * order.getQuantity();
        order.setId(UUID.randomUUID().toString());
        order.setTotalAmount(totalPrice);
        order.setStatus("PENDING_PAYMENT");
        orderRepo.save(order);

        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setOrderId(order.getId());
        paymentRequest.setAmount(totalPrice);
        paymentRequest.setPaymentMethod("Credit Card");

        PaymentResponse paymentResponse = paymentClient.makePayment(paymentRequest);
        if ("SUCCESS".equals(paymentResponse.getStatus())) {
            order.setStatus("CONFIRMED");
            productClient.reduceStock(order.getProductId(), order.getQuantity());
        }
        orderRepo.save(order);
        return order;
    }
    
    @GetMapping
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }
}